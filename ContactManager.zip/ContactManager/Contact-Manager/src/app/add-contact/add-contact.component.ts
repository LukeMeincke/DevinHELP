import { Component, OnInit, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {

  @Output() contactAdded = new EventEmitter<{firstName: string, lastName: string, phoneNumber: string}>();

  constructor() { }

  ngOnInit(): void {
  }

  onCreateContact(contactFirstName: string, contactLastName: string, contactPhoneNumber: string) {
      this.contactAdded.emit({
        firstName: contactFirstName,
        lastName: contactLastName,
        phoneNumber: contactPhoneNumber
      });
  }
}
