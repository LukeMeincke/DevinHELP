import { Component } from '@angular/core';
import { EditorType } from './contact/contact.component';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  contacts = [
      {
        firstName: "John",
        lastName: "Doe",
        phoneNumber: "111-222-4444"
      }
  ];

  onContactAdded(newContact: {firstName: string, lastName: string, phoneNumber: string}) {
      this.contacts.push(newContact);
  }

  onContactChanged(updateInfo: {id: number, newFirstName: string, newLastName: string, newPhoneNumber: string}) {
      this.contacts[updateInfo.id].firstName = updateInfo.newFirstName;
      this.contacts[updateInfo.id].lastName = updateInfo.newLastName;
      this.contacts[updateInfo.id].phoneNumber = updateInfo.newPhoneNumber;
  }

  
  
}
