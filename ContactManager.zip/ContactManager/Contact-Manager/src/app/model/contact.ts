
export interface Contact {
    firstName: string;
    lastName: string;
    phoneNumber: string;
}