import { Component, OnInit, Input, Output } from '@angular/core';

export type EditorType = 'name'|'edit';
 


@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  
  @Input() contact: {firstName: string, lastName: string, phoneNumber: string};
  
  constructor() { }

  ngOnInit(): void {
  }

  editor: EditorType = 'name';

  get shoeNameEditor() {
    return this.editor === 'name';
  }

  get showProfileEditor() {
    return this.editor === 'edit';
  }

  toggleEditor(type: EditorType) {
    this.editor = type;
  }
}
