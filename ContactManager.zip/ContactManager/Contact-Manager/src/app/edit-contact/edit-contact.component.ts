import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';


@Component({
  selector: 'app-edit-contact',
  templateUrl: './edit-contact.component.html',
  styleUrls: ['./edit-contact.component.css']
})
export class EditContactComponent {

  @Input() contact: {firstName: string, lastName: string, phoneNumber: string};
  @Input() id: number;
  @Output() contactChange = new EventEmitter<{id: number, newFirstName: string, newLastName: string, newPhoneNumber: string}>();


  onSetTo(firstName: string, lastName: string, phoneNumber: string) {
    this.contactChange.emit({
      id: this.id,
      newFirstName: firstName,
      newLastName: lastName,
      newPhoneNumber: phoneNumber
    });
  }
  
  

}
